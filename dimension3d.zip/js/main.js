/* main.js — escena Three.js (render), animación progresiva y enlace con la interfaz */
const C={mag:0xD946A6,cor:0xFF765E,yel:0xF2CB57,gry:0xF1F0F5};
const clamp=(v,a,b)=>Math.min(b,Math.max(a,v)),V3=(x,y,z)=>new THREE.Vector3(x,y,z),V2=(x,y)=>new THREE.Vector2(x,y);
const st={id:'hex',p:G.defaults('hex'),t:0,play:false,axes:true,grid:true,labels:true};
let R,scene,cam,ctl,M,solid,grid,axes,floor,ref={},labs=[],dirty=true;
const mat=(c,o={})=>new THREE.MeshStandardMaterial({color:c,roughness:.4,metalness:.15,side:THREE.DoubleSide,...o});
const line=(pts,c,loop)=>new (loop?THREE.LineLoop:THREE.Line)(new THREE.BufferGeometry().setFromPoints(pts),new THREE.LineBasicMaterial({color:c}));
function lab(txt,f,on=()=>true){const el=document.createElement('div');el.className='lab';el.textContent=txt;$('labels').appendChild(el);labs.push({el,f,on})}

function initScene(){
 R=new THREE.WebGLRenderer({antialias:true,alpha:true});R.setPixelRatio(Math.min(devicePixelRatio,2));R.shadowMap.enabled=true;$('gl').appendChild(R.domElement);
 scene=new THREE.Scene();cam=new THREE.PerspectiveCamera(45,1,.1,100);
 scene.add(new THREE.HemisphereLight(0xF1F0F5,0x21143D,.75));
 const dl=new THREE.DirectionalLight(0xffffff,.9);dl.position.set(5,9,6);dl.castShadow=true;scene.add(dl);
 const pl=new THREE.PointLight(0xD946A6,.9,40);pl.position.set(-6,3,-4);scene.add(pl);
 ctl=new THREE.OrbitControls(cam,R.domElement);ctl.enableDamping=true;ctl.minDistance=2;ctl.maxDistance=40;
 M=new THREE.Group();scene.add(M);
 axes=new THREE.AxesHelper(3);scene.add(axes);
 grid=new THREE.GridHelper(14,14,C.yel,0x6b4a8f);grid.material.transparent=true;grid.material.opacity=.5;scene.add(grid);
 floor=new THREE.Mesh(new THREE.PlaneGeometry(14,14).rotateX(-Math.PI/2),new THREE.ShadowMaterial({opacity:.3}));floor.receiveShadow=true;scene.add(floor);
 new ResizeObserver(resize).observe($('stage'));resize();
}
function resize(){const s=$('stage'),w=s.clientWidth,h=s.clientHeight;if(!w||!h)return;R.setSize(w,h);cam.aspect=w/h;cam.updateProjectionMatrix()}

// Construye el sólido según el ejemplo activo y los parámetros
function build(){
 if(solid){solid.traverse(c=>c.geometry&&c.geometry.dispose());M.remove(solid)}
 solid=new THREE.Group();M.add(solid);$('labels').innerHTML='';labs=[];ref={};
 const{id,p}=st;let fy=0;
 if(id==='hex'){ // EXTRUSIÓN: hexágono desplazado a lo largo de +Y
  const{a,h}=p,ap=a*Math.sqrt(3)/2,k=PI/6,lg=new THREE.CylinderGeometry(a,a,1,6,1,true);
  const lat=new THREE.Mesh(lg,mat(C.mag,{flatShading:true,transparent:true,opacity:.9}));lat.rotation.y=PI/2;lat.castShadow=true;
  lat.add(new THREE.LineSegments(new THREE.EdgesGeometry(lg),new THREE.LineBasicMaterial({color:C.gry})));
  const cg=new THREE.CircleGeometry(a,6).rotateX(-PI/2),bot=new THREE.Mesh(cg,mat(C.yel)),top=new THREE.Mesh(cg,mat(C.cor));
  solid.add(lat,bot,top,new THREE.ArrowHelper(V3(0,1,0),V3(a+.6,0,0),h+.4,C.yel,.35,.2),
   line([V3(0,.01,0),V3(ap*Math.cos(k),.01,-ap*Math.sin(k))],C.yel),line([V3(a,.01,0),V3(a/2,.01,-ap)],C.gry));
  ref={lat,top,h};const th=()=>h*st.t;
  lab('a (lado)',()=>V3(ap*Math.cos(k)*1.25,0,-ap*Math.sin(k)*1.25));
  lab('ap (apotema)',()=>V3(ap*Math.cos(k)*.4,.2,-ap*Math.sin(k)*.4));
  lab('h (dirección de extrusión)',()=>V3(a+.6,th()/2,0),()=>st.t>.03);
  lab('Base superior',()=>V3(0,th()+.25,0),()=>st.t>.03);
  lab('Base inferior',()=>V3(-a*.5,0,a*.4));
  lab('Cara lateral',()=>V3(-a*.87,th()/2,0),()=>st.t>.03);
 }else{ // REVOLUCIÓN: perfil en el plano XY girando alrededor del eje Y
  let ext;ref={parts:[]};
  if(id==='bic'){const{r,h1,h2}=p;fy=-h2;ext=Math.max(h1,h2)+.8;
   const P=[V2(0,-h2),V2(r,0),V2(0,h1)];
   [[[V2(r,0),V2(0,h1)],C.cor],[[V2(0,-h2),V2(r,0)],C.mag]].forEach(([pts,c])=>{const m=new THREE.Mesh(new THREE.BufferGeometry(),mat(c,{transparent:true,opacity:.92}));m.castShadow=true;solid.add(m);ref.parts.push({m,pts,seg:64})});
   ref.shape=P;ref.ghost=line(P.map(q=>V3(q.x,q.y,0)),C.gry,true);
   ref.gen=new THREE.LineSegments(new THREE.BufferGeometry(),new THREE.LineBasicMaterial({color:C.gry}));ref.arc=line([V3(r,0,0),V3(r,0,0)],C.yel);
   solid.add(ref.ghost,ref.gen,ref.arc,line([V3(0,-ext,0),V3(0,ext,0)],C.cor),line([V3(0,0,0),V3(r,0,0)],C.yel));
   lab('r (radio)',()=>V3(r/2,.15,0));lab('h₁',()=>V3(.25,h1/2,0));lab('h₂',()=>V3(.25,-h2/2,0));
   lab('g₁ (generatriz)',()=>V3(r*.6,h1*.55,0));lab('g₂ (generatriz)',()=>V3(r*.6,-h2*.55,0));
   lab('Vértice superior',()=>V3(0,h1+.25,0));lab('Vértice inferior',()=>V3(0,-h2-.25,0));
   lab('Circunferencia común',()=>V3(r*1.05,.3,0),()=>st.t>.03);lab('Eje de revolución',()=>V3(0,ext+.2,0));
  }else{const{a,b}=p;fy=-a;ext=a+.8;
   const pts=Array.from({length:49},(_,i)=>{const th=-PI/2+i*PI/48;return V2(b*Math.cos(th),a*Math.sin(th))});
   const m=new THREE.Mesh(new THREE.BufferGeometry(),mat(C.mag,{transparent:true,opacity:.92}));m.castShadow=true;solid.add(m);ref.parts.push({m,pts,seg:64});
   ref.shape=pts;ref.ghost=line(Array.from({length:65},(_,i)=>V3(b*Math.cos(i*PI/32),a*Math.sin(i*PI/32),0)),C.gry);
   solid.add(ref.ghost,line([V3(0,-ext,0),V3(0,ext,0)],C.cor),line([V3(-b,0,0),V3(b,0,0)],C.yel),line([V3(0,0,-b),V3(0,0,b)],C.yel));
   lab('a (semieje mayor = eje de revolución)',()=>V3(0,a*.6,0));lab('b (semieje menor)',()=>V3(b*.7,.1,0));lab('b (semieje menor)',()=>V3(0,.1,b*.8));
   lab('2a (altura)',()=>V3(0,-a-.3,0));lab('2b (diámetro)',()=>V3(-b-.2,-.2,0));
  }
  ref.prof=new THREE.Mesh(new THREE.ShapeGeometry(new THREE.Shape(ref.shape)),mat(C.yel,{transparent:true,opacity:.85}));solid.add(ref.prof);
 }
 grid.position.y=floor.position.y=fy-.01;dirty=true;
}

// Aplica el porcentaje de transformación t∈[0,1]
function applyT(){
 const t=st.t;
 if(st.id==='hex'){const{lat,top,h}=ref;lat.scale.y=Math.max(h*t,1e-4);lat.position.y=h*t/2;top.position.y=h*t;top.visible=t>.003}
 else{const phi=Math.max(t*2*PI,.001);
  ref.parts.forEach(o=>{o.m.geometry.dispose();o.m.geometry=new THREE.LatheGeometry(o.pts,o.seg,PI/2,phi)}); // phiStart=π/2 → arranca en el plano XY
  ref.prof.rotation.y=phi;
  if(ref.gen){const{r,h1,h2}=st.p,q=[];for(let k=0;k<12;k++){const f=k*PI/6;if(f>phi)break;const s=V3(r*Math.cos(f),0,-r*Math.sin(f));q.push(V3(0,h1,0),s,V3(0,-h2,0),s)}
   ref.gen.geometry.dispose();ref.gen.geometry=new THREE.BufferGeometry().setFromPoints(q);
   const arc=Array.from({length:49},(_,i)=>{const f=phi*i/48;return V3(r*Math.cos(f),0,-r*Math.sin(f))});ref.arc.geometry.dispose();ref.arc.geometry=new THREE.BufferGeometry().setFromPoints(arc)}}
 $('prog').value=t*1000;$('pct').textContent=Math.round(t*100)+'%';
 const n=TXT[st.id].S.length,i=Math.min(n-1,Math.floor(t*n));
 document.querySelectorAll('#steps li').forEach((li,j)=>li.classList.toggle('on',j===i));
}
function updLabels(){const w=$('stage').clientWidth,h=$('stage').clientHeight;
 labs.forEach(l=>{const v=l.f();M.localToWorld(v);v.project(cam);const vis=st.labels&&v.z<1&&l.on();l.el.style.display=vis?'block':'none';
  if(vis)l.el.style.transform=`translate(${(v.x+1)/2*w}px,${(1-v.y)/2*h}px) translate(-50%,-110%)`})}

// Estado de reproducción y vistas
function setT(v){st.t=clamp(v,0,1);dirty=true}
function setPlay(v){st.play=v;$('bPlay').textContent=v?'⏸ Pausar':(st.t>0&&st.t<1?'▶ Continuar':'▶ Iniciar')}
function placeCam(k){const{id,p}=st,S=id==='hex'?Math.max(2*p.a,p.h):id==='bic'?Math.max(2*p.r,p.h1+p.h2):2*p.a;
 const tg=V3(0,id==='hex'?p.h/2:0,0);ctl.target.copy(tg);
 const o=k==='2d'?(id==='hex'?V3(0,S*2.2,.01):V3(0,0,S*2.4)):V3(S*.9,S*.8,S*1.5);
 cam.position.copy(tg).add(o);M.rotation.set(0,0,0);ctl.update()}
function setView(v){document.querySelectorAll('#bV2,#bVP,#bV3').forEach(b=>b.classList.remove('on'));
 if(v==='2d'){setT(0);setPlay(false);placeCam('2d');$('bV2').classList.add('on')}
 else if(v==='3d'){setT(1);setPlay(false);placeCam('3d');$('bV3').classList.add('on')}
 else{placeCam('3d');setT(0);setPlay(true);$('bVP').classList.add('on')}}
function select(id){st.id=id;st.p=G.defaults(id);
 document.querySelectorAll('.card').forEach(c=>c.classList.toggle('on',c.dataset.id===id));
 $('head').innerHTML=headHTML(id);$('params').innerHTML=paramsHTML(id,st.p);$('info').innerHTML=infoHTML(id);$('err').textContent='';
 build();placeCam('3d');setT(0);setPlay(false);renderRes()}
const renderRes=()=>$('res').innerHTML=resHTML(st.id,st.p,G.calc(st.id,st.p));

// API usada por el control gestual
const App={
 setT:v=>{setT(v);setPlay(false)},
 rotate:(dx,dy)=>{M.rotation.y+=dx;M.rotation.x=clamp(M.rotation.x+dy,-1.3,1.3)},
 zoom:f=>{const d=cam.position.clone().sub(ctl.target);d.setLength(clamp(d.length()*f,2,40));cam.position.copy(ctl.target).add(d)},
 resetView:()=>placeCam('3d')};

function loop(now){requestAnimationFrame(loop);const dt=Math.min((now-(loop.l||now))/1000,.1);loop.l=now;
 if(st.play){setT(st.t+dt/6);if(st.t>=1)setPlay(false)}
 if(dirty){applyT();dirty=false}
 ctl.update();updLabels();R.render(scene,cam)}

function init(){
 initScene();$('cards').innerHTML=cardsHTML();select('hex');requestAnimationFrame(loop);
 $('cards').onclick=e=>{const c=e.target.closest('.card');if(c)select(c.dataset.id)};
 $('bPlay').onclick=()=>{if(st.t>=1)setT(0);setPlay(!st.play)};
 $('bReset').onclick=()=>{setT(0);setPlay(true)};
 $('prog').oninput=e=>{setT(e.target.value/1000);setPlay(false)};
 $('bV2').onclick=()=>setView('2d');$('bVP').onclick=()=>setView('proc');$('bV3').onclick=()=>setView('3d');
 const tg=(id,fn)=>$(id).onclick=e=>{const on=e.currentTarget.classList.toggle('on');fn(on)};
 tg('tAxes',on=>axes.visible=on);tg('tGrid',on=>grid.visible=on);tg('tLabels',on=>st.labels=on);
 $('bHome').onclick=()=>{select(st.id);['tAxes','tGrid','tLabels'].forEach(i=>$(i).classList.add('on'));axes.visible=grid.visible=st.labels=true};
 // Edición de parámetros con validación
 $('params').addEventListener('input',e=>{const k=e.target.dataset.k;if(!k)return;
  const p={...st.p,[k]:parseFloat(e.target.value)},er=G.validate(st.id,p);$('err').textContent=er||'';
  if(er)return;st.p=p;build();renderRes()});
 $('bGest').onclick=async e=>{if(Gest.on){Gest.stop();e.currentTarget.classList.remove('on')}else if(await Gest.start())e.currentTarget.classList.add('on')};
 $('bXR').onclick=async e=>{const s=$('stage');
  if(s.classList.contains('xr')){s.classList.remove('xr');$('xrNote').hidden=true;e.currentTarget.classList.remove('on');return}
  if(!Gest.on&&!await Gest.start())return;$('bGest').classList.add('on');s.classList.add('xr');$('xrNote').hidden=false;e.currentTarget.classList.add('on')};
}
$('enter').onclick=()=>{$('lab').hidden=false;if(!R)init();$('cover').classList.add('leave');
 requestAnimationFrame(()=>{$('lab').classList.add('show');resize()});setTimeout(()=>$('cover').hidden=true,850)};
