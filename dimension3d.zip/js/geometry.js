/* geometry.js — lógica matemática pura (sin Three.js ni DOM) */
const G=(()=>{
const PI=Math.PI,S3=Math.sqrt(3),r3=x=>+x.toFixed(3),eq=(x,y)=>Math.abs(x-y)<1e-9;
// Definición de los tres casos y de sus parámetros editables
const D={
 hex:{name:'Hexágono regular',solid:'Prisma hexagonal',type:'Extrusión',
  P:[{k:'a',l:'Lado a (u)',v:2,min:.5,max:4},{k:'h',l:'Altura h (u)',v:3,min:.5,max:6}]},
 bic:{name:'Triángulo isósceles',solid:'Bicono',type:'Revolución',
  P:[{k:'r',l:'Radio r (u)',v:1.8,min:.5,max:4},{k:'h1',l:'Altura superior h₁ (u)',v:2,min:.5,max:5},{k:'h2',l:'Altura inferior h₂ (u)',v:2,min:.5,max:5}]},
 ell:{name:'Elipse',solid:'Elipsoide de revolución',type:'Revolución',
  P:[{k:'a',l:'Semieje mayor a (u)',v:3,min:.5,max:5},{k:'b',l:'Semieje menor b (u)',v:1.5,min:.5,max:5}]}};
const defaults=id=>Object.fromEntries(D[id].P.map(q=>[q.k,q.v]));
// Devuelve un mensaje de error o null si los parámetros son válidos
function validate(id,p){
 for(const q of D[id].P){const v=p[q.k];
  if(!Number.isFinite(v)||v<=0)return `${q.l}: ingrese un número positivo.`;
  if(v<q.min||v>q.max)return `${q.l}: use un valor entre ${q.min} y ${q.max}.`}
 if(id==='ell'&&p.a<p.b)return 'El semieje mayor debe cumplir a ≥ b (eje de revolución = eje mayor).';
 return null}
// Cálculo de magnitudes: vars=[símbolo TeX, valor, unidad, significado]
function calc(id,p){
 if(id==='hex'){const{a,h}=p,ap=a*S3/2,P=6*a,Ab=1.5*S3*a*a,Al=P*h,V=Ab*h,A=2*Ab+Al;
  return{V,A,msg:'',vars:[['a',a,'u','lado del hexágono'],['a_p',ap,'u','apotema = a√3/2'],['P',P,'u','perímetro de la base'],['h',h,'u','altura = distancia de extrusión'],['A_b',Ab,'u²','área de cada base'],['A_l',Al,'u²','área lateral (6 rectángulos)']],
   eq:[`V=${r3(Ab)}\\cdot${h}=${r3(V)}`,`A=2(${r3(Ab)})+${r3(Al)}=${r3(A)}`]}}
 if(id==='bic'){const{r,h1,h2}=p,g1=Math.hypot(r,h1),g2=Math.hypot(r,h2),h=h1+h2,V=PI*r*r*h/3,A=PI*r*(g1+g2);
  const iso=eq(g1,g2)||eq(g1,h)||eq(g2,h);
  const msg=eq(h1,h2)?'h₁ = h₂: triángulo isósceles simétrico (g₁ = g₂).':iso?'h₁ ≠ h₂: el perfil ya no es simétrico, aunque sigue siendo isósceles porque otros dos lados coinciden.':'h₁ ≠ h₂: el perfil deja de ser un triángulo isósceles.';
  return{V,A,msg,vars:[['r',r,'u','radio de la base común'],['h_1',h1,'u','altura del cono superior'],['h_2',h2,'u','altura del cono inferior'],['h',h,'u','altura total = h₁+h₂'],['g_1',g1,'u','generatriz superior'],['g_2',g2,'u','generatriz inferior']],
   eq:[`V=\\tfrac13\\pi(${r})^2(${r3(h)})=${r3(V)}`,`A=\\pi(${r})(${r3(g1)}+${r3(g2)})=${r3(A)}`]}}
 const{a,b}=p,e=Math.sqrt(Math.max(0,1-b*b/(a*a))),sph=eq(a,b),V=4/3*PI*a*b*b;
 const A=sph?4*PI*a*a:2*PI*b*b*(1+a/(b*e)*Math.asin(e));
 return{V,A,msg:sph?'a = b: el elipsoide es una esfera y se usa el caso especial A = 4πa².':'',
  vars:[['a',a,'u','semieje mayor (eje de revolución)'],['b',b,'u','semieje menor (×2 en el sólido)'],['2a',2*a,'u','altura total del sólido'],['2b',2*b,'u','diámetro transversal'],['e',e,'','excentricidad']],
  eq:[`V=\\tfrac43\\pi(${a})(${b})^2=${r3(V)}`,sph?`A=4\\pi a^2=${r3(A)}`:`A=2\\pi b^2\\left[1+\\tfrac{a}{be}\\arcsin e\\right]=${r3(A)}`]}}
return{D,defaults,validate,calc}})();
