/* interface.js — textos didácticos, ficha matemática, catálogo y portada animada */
const $=id=>document.getElementById(id),PI=Math.PI;
const T=s=>window.katex?katex.renderToString(s,{throwOnError:false}):`<code>${s}</code>`;
const fx=x=>(+x).toFixed(3).replace(/\.?0+$/,'');
function toast(m){const t=$('toast');t.textContent=m;t.hidden=false;clearTimeout(toast.h);toast.h=setTimeout(()=>t.hidden=true,5000)}

const TXT={
hex:{F:[['A_b=\\tfrac{3\\sqrt3}{2}a^2','área de la base'],['P=6a','perímetro'],['V=A_b\\,h','volumen'],['A_l=P\\,h','área lateral'],['A=2A_b+A_l','área total']],
 C:'En una extrusión, una región plana se desplaza a lo largo de una dirección perpendicular a su plano. Cada lado del hexágono barre un rectángulo (las 6 caras laterales); el hexágono inicial y su copia desplazada son las dos bases.',
 S:['Se parte de un hexágono regular de lado a en el plano horizontal.','Se fija la dirección de extrusión, perpendicular al plano de la base.','El hexágono se desplaza una distancia h; cada lado barre un rectángulo.','Aparecen las 6 caras laterales (área P·h) y la base superior.','Resultado: prisma hexagonal, V = A_b·h y A = 2A_b + A_l.'],
 Q:['¿Qué sucede con el volumen cuando aumenta la altura del prisma?','¿Qué diferencias existen entre una extrusión y una revolución?'],N:''},
bic:{F:[['h=h_1+h_2','altura total'],['g_i=\\sqrt{r^2+h_i^2}','generatrices'],['V=\\tfrac13\\pi r^2h_1+\\tfrac13\\pi r^2h_2=\\tfrac13\\pi r^2h','volumen'],['A_l=\\pi r g_1+\\pi r g_2','área lateral exterior'],['A=A_l','área superficial exterior']],
 C:'En una revolución, una región plana gira alrededor de un eje. Aquí la base del triángulo (longitud h = h₁ + h₂) está sobre el eje y su vértice libre queda a distancia r. La altura r es perpendicular al eje y, si h₁ = h₂, es el eje de simetría del triángulo. Cada mitad genera un cono y ambos comparten una circunferencia de radio r.',
 S:['Se dibuja el triángulo isósceles: base h sobre el eje y vértice a distancia r.','Si h₁ = h₂, los lados g₁ y g₂ son iguales (perfil simétrico).','El triángulo gira progresivamente alrededor del eje de revolución.','Cada lado inclinado barre una superficie cónica (generatrices g₁ y g₂).','A 360° quedan dos conos unidos por la circunferencia común.'],
 Q:['¿Cómo se relaciona el radio de los conos con el volumen del bicono?','¿Cómo influye el eje de revolución en la forma del sólido?'],
 N:'La circunferencia compartida es una superficie interna de unión: no se incluye en el área superficial exterior.'},
ell:{F:[['\\frac{x^2}{a^2}+\\frac{y^2}{b^2}=1','ecuación de la elipse'],['e=\\sqrt{1-b^2/a^2}','excentricidad'],['V=\\tfrac43\\pi a b^2','volumen'],['A=2\\pi b^2\\left[1+\\tfrac{a}{be}\\arcsin e\\right]','área (elipsoide prolato)'],['a=b\\Rightarrow A=4\\pi a^2','caso esfera']],
 C:'La elipse gira alrededor de su eje mayor. Cada punto describe una circunferencia perpendicular al eje; el semieje menor b genera el círculo ecuatorial. El sólido tiene un semieje mayor a y dos semiejes menores iguales b.',
 S:['Se parte de la elipse x²/a² + y²/b² = 1 con a ≥ b.','El semieje mayor se toma como eje de revolución.','La región gira alrededor del eje; cada punto traza una circunferencia.','Los extremos del eje mayor son los polos; b define el ecuador.','A 360° se obtiene el elipsoide de revolución, simétrico respecto al eje y al plano ecuatorial.'],
 Q:['¿Qué sucede con el elipsoide cuando los dos semiejes tienen la misma longitud?','¿Cómo influye el eje de revolución en la forma del sólido?'],
 N:'El área del elipsoide no tiene la misma expresión general que la de la esfera (4πr²): depende de la excentricidad e. Solo si a = b se usa A = 4πa².'}};

// Miniaturas del catálogo (figura plana → sólido)
const hp=(cx,cy,r)=>[0,1,2,3,4,5].map(i=>`${(cx+r*Math.cos(i*PI/3)).toFixed(1)},${(cy+r*.45*Math.sin(i*PI/3)).toFixed(1)}`).join(' ');
const arrow='<path d="M52 24h16m-5-4 5 4-5 4" fill="none" stroke="#F2CB57" stroke-width="2"/>';
const THUMB={
hex:`<polygon points="${hp(24,24,14)}" fill="#F2CB57" opacity=".9"/>${arrow}<polygon points="${hp(92,36,14)}" fill="#F2CB57"/><path d="M78 36V14M106 36V14M85 40V18M99 40V18" stroke="#FF765E"/><polygon points="${hp(92,14,14)}" fill="#D946A6"/>`,
bic:`<polygon points="24,6 24,42 42,24" fill="#F2CB57"/>${arrow}<path d="M76 24 92 4 108 24 92 44Z" fill="#D946A6"/><ellipse cx="92" cy="24" rx="16" ry="4" fill="none" stroke="#F2CB57"/>`,
ell:`<ellipse cx="26" cy="24" rx="10" ry="18" fill="#F2CB57"/>${arrow}<ellipse cx="92" cy="24" rx="12" ry="19" fill="#D946A6"/><ellipse cx="92" cy="24" rx="12" ry="4" fill="none" stroke="#F2CB57"/>`};
const cardsHTML=()=>Object.keys(G.D).map(id=>`<button class="btn card" data-id="${id}"><svg viewBox="0 0 120 48">${THUMB[id]}</svg><b>${G.D[id].name} → ${G.D[id].solid}</b><small>${G.D[id].type}</small></button>`).join('');
const headHTML=id=>`<small>${G.D[id].type}</small><h2>${G.D[id].name} → ${G.D[id].solid}</h2>`;
const paramsHTML=(id,p)=>G.D[id].P.map(q=>`<label>${q.l}<input type="number" data-k="${q.k}" step="0.1" min="${q.min}" max="${q.max}" value="${p[q.k]}"></label>`).join('');
// Resultados numéricos (se recalculan al cambiar parámetros)
function resHTML(id,p,c){
 return `<div class="kpi"><div><small>Volumen</small><b>${fx(c.V)} u³</b></div><div><small>Área superficial</small><b>${fx(c.A)} u²</b></div></div>
 <table>${c.vars.map(v=>`<tr><td>${T(v[0])}</td><td>${v[3]}</td><td><b>${fx(v[1])}</b> ${v[2]}</td></tr>`).join('')}</table>
 ${c.eq.map(e=>`<div class="eq">${T(e)}</div>`).join('')}${c.msg?`<div class="msg">${c.msg}</div>`:''}`}
// Fórmulas, concepto, pasos y preguntas orientadoras
function infoHTML(id){const x=TXT[id];
 return `<h3>Ecuaciones y fórmulas</h3>${x.F.map(f=>`<div class="f">${T(f[0])}<span>${f[1]}</span></div>`).join('')}
 <h3>Explicación conceptual</h3><p>${x.C}</p>${x.N?`<div class="msg">${x.N}</div>`:''}
 <h3>¿CÓMO SE GENERA ESTE SÓLIDO?</h3><ol id="steps">${x.S.map(s=>`<li>${s}</li>`).join('')}</ol>
 <h3>Preguntas orientadoras</h3><ul class="q">${x.Q.map(q=>`<li>${q}</li>`).join('')}</ul>`}

// Portada: figuras planas que se transforman en sólidos (canvas 2D)
(()=>{const c=$('coverCanvas'),x=c.getContext('2d');let t=0,w,h;
 const rs=()=>{w=c.width=innerWidth;h=c.height=innerHeight};rs();addEventListener('resize',rs);
 const hexp=(cx,cy,r,k)=>[0,1,2,3,4,5].map(i=>[cx+r*Math.cos(i*PI/3+k),cy+r*.4*Math.sin(i*PI/3+k)]);
 const poly=(P,f,s)=>{x.beginPath();P.forEach((p,i)=>i?x.lineTo(p[0],p[1]):x.moveTo(p[0],p[1]));x.closePath();if(f){x.fillStyle=f;x.fill()}if(s){x.strokeStyle=s;x.stroke()}};
 (function L(){requestAnimationFrame(L);if($('cover').hidden)return;t+=.012;x.clearRect(0,0,w,h);
  const u=Math.min(w,h)/9,s=(Math.sin(t)+1)/2;x.lineWidth=2;
  x.strokeStyle='rgba(241,240,245,.12)';for(let i=-10;i<=10;i++){x.beginPath();x.moveTo(w/2+i*u*.6,h*.62);x.lineTo(w/2+i*u*1.8,h);x.stroke()}
  for(let j=0;j<5;j++){const y=h*.62+j*j*u*.12+j*u*.15;x.beginPath();x.moveTo(0,y);x.lineTo(w,y);x.stroke()}
  // ejes cartesianos
  x.strokeStyle='#F2CB57';x.beginPath();x.moveTo(w*.5,h*.08);x.lineTo(w*.5,h*.2);x.moveTo(w*.5-u*.6,h*.14);x.lineTo(w*.5+u*.6,h*.14);x.stroke();
  // hexágono → prisma (extrusión)
  const cx=w*.17,cy=h*.72,H=s*u*2.6,B=hexp(cx,cy,u*1.3,t*.4),Tp=B.map(p=>[p[0],p[1]-H]);
  B.forEach((p,i)=>{x.strokeStyle='#FF765E';x.beginPath();x.moveTo(p[0],p[1]);x.lineTo(Tp[i][0],Tp[i][1]);x.stroke()});
  poly(B,'rgba(242,203,87,.35)','#F2CB57');poly(Tp,'rgba(217,70,166,.55)','#D946A6');
  // elipse → elipsoide (revolución)
  const ex=w*.83,ey=h*.36;x.strokeStyle='#FF765E';
  for(let k=0;k<6;k++){x.beginPath();x.ellipse(ex,ey,u*1.1*Math.abs(Math.cos(t+k*PI/6)),u*1.7,0,0,2*PI);x.stroke()}
  x.strokeStyle='#F2CB57';x.beginPath();x.ellipse(ex,ey,u*1.1,u*.3,0,0,2*PI);x.stroke();
  // triángulo → bicono
  const bx=w*.84,by=h*.74,rr=u*1.1*(.3+.7*Math.abs(Math.cos(t*.8)));
  poly([[bx,by-u*1.2],[bx+rr,by],[bx,by+u*1.2],[bx-rr,by]],'rgba(217,70,166,.35)','#D946A6');
  x.strokeStyle='#F2CB57';x.beginPath();x.ellipse(bx,by,rr,u*.25,0,0,2*PI);x.stroke();
 })()})();
