/* gesture-control.js — MediaPipe Hands reconoce los gestos; Three.js (App) ejecuta las acciones */
const Gest=(()=>{
 const vid=$('cam'),cv=$('camCanvas'),cx=cv.getContext('2d'),info=$('gestureInfo'),ptr=$('pointer');
 let hands,stream,on=false,busy=false,cand='',cnt=0,gest='',prev=null,pd=null,dw={el:null,t0:0},lastReset=0;
 const NAME={open:'Palma abierta',point:'Índice levantado',pinch:'Pinza',fist:'Puño cerrado',two:'Dos manos'};
 const ACT={open:'rotar sólido',point:'puntero (mantén sobre un botón)',pinch:'avance de la transformación',fist:'restablecer vista',two:'zoom'};
 const d=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
 // Clasifica una mano usando distancias a la muñeca (independiente de la orientación)
 function classify(l){const s=d(l[0],l[9])||1,e=[8,12,16,20].map(i=>d(l[i],l[0])>d(l[i-2],l[0])*1.05),n=e.filter(Boolean).length;
  if(d(l[4],l[8])/s<.28&&(e[1]||e[2]||e[3]))return'pinch';
  if(n===4)return'open';if(n===0)return'fist';if(e[0]&&n===1)return'point';return''}
 function onRes(r){
  cx.drawImage(r.image,0,0,240,180);const L=r.multiHandLandmarks||[];
  L.forEach(l=>{cx.strokeStyle='#F2CB57';cx.lineWidth=2;(window.HAND_CONNECTIONS||[]).forEach(([a,b])=>{cx.beginPath();cx.moveTo(l[a].x*240,l[a].y*180);cx.lineTo(l[b].x*240,l[b].y*180);cx.stroke()});
   cx.fillStyle='#D946A6';l.forEach(p=>{cx.beginPath();cx.arc(p.x*240,p.y*180,2.5,0,7);cx.fill()})});
  ptr.hidden=true;let g='';
  if(L.length>=2)g='two';else if(L.length===1)g=classify(L[0]);
  // Anti-activación involuntaria: el gesto debe mantenerse 4 fotogramas seguidos
  if(g===cand)cnt++;else{cand=g;cnt=0}if(cnt>=4)gest=cand;if(!g)gest='';
  const now=performance.now();
  if(gest==='two'&&L.length>=2){const dd=d(L[0][9],L[1][9]);if(pd)App.zoom(clamp(pd/dd,.9,1.1));pd=dd}else pd=null;
  if(gest==='open'&&L.length===1){const c=L[0][9];if(prev&&Math.hypot(c.x-prev.x,c.y-prev.y)>.002)App.rotate((prev.x-c.x)*6,(c.y-prev.y)*4);prev={x:c.x,y:c.y}}else prev=null;
  if(gest==='pinch'&&L.length===1)App.setT(clamp(((1-L[0][8].x)-.15)/.7,0,1));
  if(gest==='fist'&&now-lastReset>1500){App.resetView();lastReset=now}
  if(gest==='point'&&L.length===1){ // puntero gestual con selección por permanencia (0,9 s)
   const t=L[0][8],x=(1-t.x)*innerWidth,y=t.y*innerHeight;ptr.hidden=false;ptr.style.transform=`translate(${x}px,${y}px)`;
   const el=document.elementFromPoint(x,y);const b=el&&el.closest('button');
   if(b&&b===dw.el){const f=(now-dw.t0)/900;ptr.style.setProperty('--p',clamp(f,0,1));if(f>=1){b.click();dw={el:b,t0:now+1500};ptr.style.setProperty('--p',0)}}
   else{dw={el:b,t0:now};ptr.style.setProperty('--p',0)}}
  info.textContent=gest?`${NAME[gest]} → ${ACT[gest]}`:(L.length?'Gesto no reconocido':'Sin manos')}
 async function start(){
  if(!window.Hands){toast('MediaPipe no se pudo cargar (¿sin conexión?). Usa el mouse.');return false}
  try{stream=await navigator.mediaDevices.getUserMedia({video:{width:640,height:480,facingMode:'user'}})}
  catch(e){toast('Cámara no disponible o permiso denegado (requiere HTTPS o localhost). La aplicación funciona con el mouse.');return false}
  vid.srcObject=stream;await vid.play();
  hands=hands||new Hands({locateFile:f=>`https://cdn.jsdelivr.net/npm/@mediapipe/hands@0.4.1675469240/${f}`});
  hands.setOptions({maxNumHands:2,modelComplexity:1,minDetectionConfidence:.7,minTrackingConfidence:.6});hands.onResults(onRes);
  on=true;$('camBox').hidden=false;info.textContent='Cargando MediaPipe…';pump();return true}
 async function pump(){if(!on)return;if(vid.readyState>=2&&!busy){busy=true;try{await hands.send({image:vid})}catch(e){}busy=false}requestAnimationFrame(pump)}
 function stop(){on=false;if(stream)stream.getTracks().forEach(t=>t.stop());stream=null;$('camBox').hidden=true;ptr.hidden=true;$('stage').classList.remove('xr');$('xrNote').hidden=true;$('bXR').classList.remove('on')}
 return{start,stop,get on(){return on}}})();
