# DIMENSION 3D INTERACTIVE LAB
Autor: Leonardo Isaac Barrios Marchena · Licenciatura en Matemáticas · Universidad del Magdalena

Laboratorio web que transforma figuras 2D en sólidos 3D: **hexágono → prisma hexagonal** (extrusión), **triángulo isósceles → bicono** (revolución) y **elipse → elipsoide de revolución**.

## Ejecución
- **XAMPP:** copia la carpeta en `htdocs/` y abre `http://localhost/dimension3d/`.
- **GitHub Pages:** sube el contenido al repositorio y activa Pages (HTTPS). 
- La cámara solo funciona en HTTPS o `localhost`. No abras `index.html` con `file://`.
- Sin cámara, todo funciona con el mouse (arrastrar = rotar, rueda = zoom).

## Estructura
`index.html` · `css/styles.css` · `js/geometry.js` (matemática pura) · `js/interface.js` (textos, ficha, portada) · `js/main.js` (Three.js y animaciones) · `js/gesture-control.js` (MediaPipe) · `assets/`

## Dependencias (CDN, requieren conexión)
Three.js 0.128 + OrbitControls · KaTeX 0.16.9 · MediaPipe Hands 0.4.1675469240.

## Gestos
Palma abierta: rotar · Índice: puntero (mantener 0,9 s sobre un botón) · Pinza (con los otros dedos extendidos): avance, según la posición horizontal de la mano · Dos manos: zoom · Puño: restablecer vista.
Un gesto debe mantenerse 4 fotogramas para activarse; el puño tiene un enfriamiento de 1,5 s.

## XR CAMERA VIEW
Superpone el modelo sobre la cámara. Es una demostración educativa: no hay anclaje espacial persistente ni reconocimiento de superficies.

## Notas matemáticas
En el bicono, la base del triángulo (h = h₁+h₂) está sobre el eje de revolución; la altura r del triángulo es perpendicular al eje. Si h₁ ≠ h₂ el perfil deja de ser simétrico (y de ser isósceles salvo coincidencias de lados). El área del bicono excluye la circunferencia de unión. El elipsoide exige a ≥ b (prolato).
